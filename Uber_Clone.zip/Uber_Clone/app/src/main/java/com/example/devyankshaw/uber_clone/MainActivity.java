package com.example.devyankshaw.uber_clone;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.parse.ParseInstallation;

public class MainActivity extends AppCompatActivity {

    //This enum is used to declare our own data type whose variable is State which holds only two values SIGNUP and LOGIN
    enum State{
        SIGNUP, LOGIN;
    }

    private State state;//Declare to initialise the state
    private Button btnSignUpLogIn, btnOneTimeLogIn;
    private RadioButton rdbPassenger,rdbDriver;
    private EditText edtUsername, edtPassword, edtDriverPassenger;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Save the current Installation to Back4App
        ParseInstallation.getCurrentInstallation().saveInBackground();

        //Initialising the state to Signup at the initial
        state = State.SIGNUP;

        btnSignUpLogIn = findViewById(R.id.btnSignUpLogIn);
        btnOneTimeLogIn = findViewById(R.id.btnOneTimeLogin);

        rdbDriver = findViewById(R.id.rdbDriver);
        rdbPassenger = findViewById(R.id.rdbPassenger);

        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);
        edtDriverPassenger = findViewById(R.id.edtDriverPassenger);

        btnSignUpLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(state == State.SIGNUP){

                    if(rdbDriver.isChecked() == false && rdbPassenger.isChecked() == false){
                        Toast.makeText(MainActivity.this, "Are you a driver or passenger?", Toast.LENGTH_SHORT).show();
                        return;//This return statement means do not execute the codes after this if statement
                    }

                }
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_signup_activity, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId()){

            case R.id.loginItem:

                if(state == State.SIGNUP){
                    state = State.LOGIN;
                    item.setTitle("Sign Up");
                    btnSignUpLogIn.setText("Log In");
                }else if(state == State.LOGIN){
                    state = State.SIGNUP;
                    item.setTitle("Log In");
                    btnSignUpLogIn.setText("Sign Up");
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
